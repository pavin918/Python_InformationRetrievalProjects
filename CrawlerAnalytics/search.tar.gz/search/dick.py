urls = set()
with open('sucmydick.txt', 'r') as file:
    for line in file:
        line = line.strip()
        urls.update(line)
print len(urls)